import {AbsoluteFill, Easing, interpolate, interpolateColors, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {C, fontFamily} from "./theme";

const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;
const prog = (f: number, a: number, b: number) =>
  interpolate(f, [a, b], [0, 1], {...clamp, easing: Easing.bezier(0.16, 1, 0.3, 1)});

const Sky: React.FC<{top: string; bottom: string}> = ({top, bottom}) => (
  <AbsoluteFill style={{background: `linear-gradient(${top}, ${bottom})`}} />
);
const Svg: React.FC<{children: React.ReactNode}> = ({children}) => (
  <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: "absolute", inset: 0}}>{children}</svg>
);

const Label: React.FC<{text: string; top: number; size?: number; delay?: number}> = ({text, top, size = 84, delay = 0}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f - delay, fps, config: {damping: 14}});
  return (
    <div style={{
      position: "absolute", top, left: 0, width: 1080, textAlign: "center", direction: "rtl",
      fontFamily, fontWeight: 900, fontSize: size, color: "#fff", textShadow: "0 6px 24px rgba(0,0,0,.35)",
      scale: s, opacity: Math.min(1, s),
    }}>{text}</div>
  );
};

const Sun: React.FC<{x: number; y: number; r: number; f: number; rays?: boolean}> = ({x, y, r, f, rays = true}) => (
  <g transform={`translate(${x} ${y})`}>
    {rays && (
      <g transform={`rotate(${f * 0.6})`}>
        {Array.from({length: 12}).map((_, i) => (
          <rect key={i} x={-8} y={-r - 70} width={16} height={50} rx={8} fill={C.sun} transform={`rotate(${i * 30})`} />
        ))}
      </g>
    )}
    <circle r={r} fill={C.sun} />
  </g>
);

const Cloud: React.FC<{x: number; y: number; s?: number}> = ({x, y, s = 1}) => (
  <g transform={`translate(${x} ${y}) scale(${s})`} fill="#fff" opacity={0.92}>
    <ellipse cx={0} cy={0} rx={120} ry={45} />
    <ellipse cx={-60} cy={-30} rx={60} ry={45} />
    <ellipse cx={30} cy={-45} rx={70} ry={55} />
  </g>
);
const drift = (f: number, o: number, speed = 1.2) => ((o + f * speed) % 1500) - 200;

// 1 ── Hook
export const Hook = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Sky top={C.blue} bottom={C.sky} />
      <Svg>
        <Sun x={800} y={330} r={130} f={f} />
        <Cloud x={drift(f, 100)} y={280} s={1.1} />
        <Cloud x={drift(f, 700, 0.8)} y={760} s={0.9} />
      </Svg>
      <Label text="لماذا السماء" top={470} size={130} delay={6} />
      <Label text="زرقاء؟" top={640} size={170} delay={16} />
    </AbsoluteFill>
  );
};

// 2 ── White light = all colours (prism)
const rainbow = ["#ff3b3b", "#ff8a1f", "#ffd91f", "#3ddc5a", "#2aa8ff", "#3d4dff", "#9b3dff"];
export const Prism = () => {
  const f = useCurrentFrame();
  const beam = prog(f, 10, 45);
  const fan = prog(f, 50, 110);
  return (
    <AbsoluteFill>
      <Sky top={C.navy} bottom="#1d3a78" />
      <Svg>
        <line x1={40} y1={560} x2={40 + beam * 416} y2={560} stroke="#fff" strokeWidth={16} strokeLinecap="round" />
        <polygon points="540,380 400,680 680,680" fill="rgba(255,255,255,.18)" stroke="#fff" strokeWidth={6} />
        {rainbow.map((c, i) => (
          <line key={i} x1={624} y1={560} x2={624 + fan * 416} y2={560 + (i - 3) * fan * 60}
            stroke={c} strokeWidth={18} strokeLinecap="round" />
        ))}
      </Svg>
      <Label text="ضوء الشمس الأبيض" top={190} size={84} />
      <Label text="مزيج من كل الألوان" top={300} size={70} delay={50} />
    </AbsoluteFill>
  );
};

// 3 ── Atmosphere with air molecules
const mols = Array.from({length: 36}, (_, i) => ({x: 60 + ((i * 173) % 960), y: 440 + ((i * 97) % 330), p: i}));
export const Atmosphere = () => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill>
      <Sky top={C.navy} bottom={C.blue} />
      <Svg>
        {Array.from({length: 5}).map((_, i) => (
          <line key={i} x1={140 + i * 200} y1={0} x2={140 + i * 200} y2={prog(f, 10 + i * 6, 60 + i * 6) * 780}
            stroke="#fff" strokeWidth={10} strokeLinecap="round" opacity={0.85} />
        ))}
        <circle cx={540} cy={1700} r={960} fill="rgba(159,212,255,.35)" />
        <circle cx={540} cy={1700} r={900} fill="#1f7a4d" />
        {mols.map((m) => (
          <circle key={m.p} cx={m.x + Math.sin(f / 12 + m.p) * 10} cy={m.y + Math.cos(f / 10 + m.p) * 10}
            r={9} fill="rgba(255,255,255,.9)" />
        ))}
      </Svg>
      <Label text="الغلاف الجوي" top={190} size={90} />
      <Label text="مليء بجزيئات صغيرة" top={300} size={64} delay={40} />
    </AbsoluteFill>
  );
};

// 4 ── Scattering: blue goes everywhere, red goes straight
const wave = (y: number, amp: number, freq: number, ph: number) => {
  let d = `M 60 ${y}`;
  for (let x = 60; x <= 1020; x += 8) d += ` L ${x} ${y + Math.sin(x * freq - ph) * amp}`;
  return d;
};
export const Scatter = () => {
  const f = useCurrentFrame();
  const t = f >= 50 ? ((f - 50) % 45) / 45 : -1;
  return (
    <AbsoluteFill>
      <Sky top="#0f2a5e" bottom={C.blue} />
      <Svg>
        <line x1={40} y1={600} x2={40 + prog(f, 10, 50) * 444} y2={600} stroke="#fff" strokeWidth={16} strokeLinecap="round" />
        <circle cx={540} cy={600} r={64} fill="rgba(207,230,255,.35)" />
        <circle cx={540} cy={600} r={50} fill="#cfe6ff" />
        {t >= 0 && Array.from({length: 12}).map((_, i) => {
          const a = (i / 12) * Math.PI * 2;
          return (
            <line key={i} x1={540 + Math.cos(a) * 80} y1={600 + Math.sin(a) * 80}
              x2={540 + Math.cos(a) * (80 + t * 300)} y2={600 + Math.sin(a) * (80 + t * 300)}
              stroke={C.scatter} strokeWidth={12} strokeLinecap="round" opacity={1 - t} />
          );
        })}
        <line x1={596} y1={600} x2={596 + prog(f, 50, 100) * 444} y2={600} stroke={C.red} strokeWidth={14} strokeLinecap="round" />
        <path d={wave(840, 22, 0.07, f * 0.25)} stroke={C.scatter} strokeWidth={10} fill="none" strokeLinecap="round" />
        <path d={wave(920, 22, 0.022, f * 0.25)} stroke={C.red} strokeWidth={10} fill="none" strokeLinecap="round" />
      </Svg>
      <Label text="تشتّت الضوء الأزرق" top={190} size={84} />
      <Label text="موجته أقصر فينتشر أكثر" top={300} size={64} delay={60} />
    </AbsoluteFill>
  );
};

// 5 ── Sunset
export const Sunset = () => {
  const f = useCurrentFrame();
  const {durationInFrames: d} = useVideoConfig();
  const sunY = interpolate(f, [0, d], [420, 830], clamp);
  return (
    <AbsoluteFill>
      <Sky top={interpolateColors(f, [0, d], [C.blue, "#ff6a3d"])} bottom={interpolateColors(f, [0, d], [C.sky, "#ffd27a"])} />
      <Svg>
        <circle cx={540} cy={sunY} r={120} fill={C.sun} />
        <polygon points="0,900 300,820 640,880 1080,800 1080,1920 0,1920" fill="#1b2a41" />
      </Svg>
      <Label text="عند الغروب" top={190} size={100} />
      <Label text="الضوء يقطع طريقًا أطول" top={320} size={66} delay={30} />
    </AbsoluteFill>
  );
};

// 6 ── Outro
export const Outro = () => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f - 40, fps, config: {damping: 10}});
  return (
    <AbsoluteFill>
      <Sky top={C.blue} bottom={C.sky} />
      <Svg><Sun x={800} y={300} r={110} f={f} /><Cloud x={drift(f, 200)} y={650} /></Svg>
      <Label text="الآن عرفت السر!" top={380} size={120} />
      <div style={{
        position: "absolute", top: 640, left: 140, width: 800, padding: "24px 0", borderRadius: 60, background: C.red,
        textAlign: "center", direction: "rtl", fontFamily, fontWeight: 900, fontSize: 68, color: "#fff",
        scale: s * (1 + 0.04 * Math.sin(f / 6)),
      }}>تابعنا لمزيد من العلوم</div>
    </AbsoluteFill>
  );
};
