import {AbsoluteFill, Sequence, interpolate, staticFile, useCurrentFrame, useVideoConfig} from "remotion";
import {Audio} from "@remotion/media";
import {Character} from "./Character";
import {Captions} from "./Captions";
import {Hook, Prism, Atmosphere, Scatter, Sunset, Outro} from "./Scenes";
import {HAS_AUDIO, LEAD, OVERLAP, scenes, starts, talkingAt} from "./timeline";

const SCENES = [Hook, Prism, Atmosphere, Scatter, Sunset, Outro];
const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

// Per-scene camera: slow push-in + small pan, cross-fade in from previous scene.
const Shell: React.FC<{i: number; children: React.ReactNode}> = ({i, children}) => {
  const f = useCurrentFrame();
  const {durationInFrames: d} = useVideoConfig();
  return (
    <AbsoluteFill style={{
      opacity: i === 0 ? 1 : interpolate(f, [0, OVERLAP], [0, 1], clamp),
      scale: interpolate(f, [0, d], [1, 1.07], clamp),
      translate: `${interpolate(f, [0, d], [i % 2 ? -14 : 14, 0], clamp)}px 0`,
    }}>{children}</AbsoluteFill>
  );
};

const Host = () => <Character talking={talkingAt(useCurrentFrame())} />;

export const SkyBlue = () => (
  <AbsoluteFill style={{background: "#000"}}>
    {scenes.map((s, i) => {
      const Scene = SCENES[i];
      return (
        <Sequence key={s.id} from={starts[i]} durationInFrames={s.frames + (i < scenes.length - 1 ? OVERLAP : 0)}>
          <Shell i={i}><Scene /></Shell>
        </Sequence>
      );
    })}
    <Host />
    {scenes.map((s, i) => (
      <Sequence key={s.id} from={starts[i]} durationInFrames={s.frames}>
        <Captions text={s.text} frames={s.frames} words={s.words} />
        {HAS_AUDIO && (
          <Sequence from={LEAD}><Audio src={staticFile(`audio/${s.id}.mp3`)} /></Sequence>
        )}
      </Sequence>
    ))}
  </AbsoluteFill>
);
