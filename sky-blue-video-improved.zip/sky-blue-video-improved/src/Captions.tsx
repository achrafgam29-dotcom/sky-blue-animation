import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {LEAD, TAIL} from "./timeline";
import {C, fontFamily} from "./theme";

type W = {text: string; startMs: number; endMs: number};

// 3-word pages, current word highlighted. Whole words only: Arabic letters stay joined.
export const Captions: React.FC<{text: string; frames: number; words?: W[]}> = ({text, frames, words}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const list = words?.length
    ? words.map((w) => ({text: w.text, at: LEAD + Math.round((w.startMs * fps) / 1000)}))
    : text.split(/\s+/).map((t, i, a) => ({text: t, at: LEAD + Math.round((i * (frames - LEAD - TAIL)) / a.length)}));
  let idx = -1;
  list.forEach((w, i) => { if (w.at <= f) idx = i; });
  if (idx < 0) return null;
  const page = Math.floor(idx / 3);
  const pop = spring({frame: f - list[page * 3].at, fps, config: {damping: 14, stiffness: 180}});
  return (
    <AbsoluteFill style={{top: 1400, height: 200, justifyContent: "center", alignItems: "center"}}>
      <div style={{
        display: "flex", flexDirection: "row", direction: "rtl", gap: 22, padding: "22px 44px",
        background: "rgba(10,20,50,.74)", borderRadius: 44, scale: 0.9 + 0.1 * pop,
        fontFamily, fontWeight: 900, fontSize: 80,
      }}>
        {list.slice(page * 3, page * 3 + 3).map((w, i) => (
          <span key={i} style={{color: page * 3 + i === idx ? C.hl : "#fff"}}>{w.text}</span>
        ))}
      </div>
    </AbsoluteFill>
  );
};
