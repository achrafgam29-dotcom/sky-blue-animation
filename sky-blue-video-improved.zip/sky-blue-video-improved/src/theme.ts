import {loadFont} from "@remotion/google-fonts/Cairo";

const {fontFamily} = loadFont("normal", {weights: ["700", "900"], subsets: ["arabic"]});
export {fontFamily};

export const C = {
  blue: "#2B7FFF", sky: "#9FD4FF", sun: "#FFC83D", red: "#FF4D4D",
  navy: "#0B1B3A", scatter: "#3AA0FF", hl: "#FFD93D",
};
