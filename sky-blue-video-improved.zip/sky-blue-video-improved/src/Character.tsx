import {useCurrentFrame} from "remotion";

// "Noor" – the host. One component, used in every scene, so she never changes.
export const Character: React.FC<{talking: boolean}> = ({talking}) => {
  const f = useCurrentFrame();
  const bob = Math.sin(f / 15) * 6;
  const mouth = talking ? 6 + Math.abs(Math.sin(f * 0.8)) * 18 : 4;
  const blink = f % 90 < 4 ? 0.1 : 1;
  const wave = Math.sin(f / 6) * 16;
  const skin = "#F2B684";
  return (
    <div style={{position: "absolute", left: 330, top: 960, width: 420, height: 420}}>
      <svg width={420} height={420} viewBox="0 0 420 420" style={{translate: `0 ${bob}px`}}>
        <ellipse cx={210} cy={412} rx={130} ry={14} fill="rgba(0,0,0,.25)" />
        <rect x={120} y={250} width={180} height={170} rx={50} fill="#fff" />
        <rect x={185} y={255} width={50} height={120} rx={12} fill="#2B7FFF" />
        <rect x={92} y={270} width={42} height={110} rx={21} fill="#fff" />
        <circle cx={113} cy={385} r={22} fill={skin} />
        <g transform={`rotate(${wave} 305 290)`}>
          <rect x={285} y={170} width={42} height={125} rx={21} fill="#fff" />
          <circle cx={306} cy={165} r={24} fill={skin} />
        </g>
        <circle cx={210} cy={150} r={95} fill={skin} />
        <path d="M113 142 Q118 42 210 48 Q302 42 307 142 Q262 88 210 94 Q158 88 113 142Z" fill="#2a1b12" />
        <ellipse cx={175} cy={152} rx={12} ry={14 * blink} fill="#222" />
        <ellipse cx={245} cy={152} rx={12} ry={14 * blink} fill="#222" />
        <circle cx={175} cy={152} r={30} fill="none" stroke="#222" strokeWidth={5} />
        <circle cx={245} cy={152} r={30} fill="none" stroke="#222" strokeWidth={5} />
        <line x1={205} y1={152} x2={215} y2={152} stroke="#222" strokeWidth={5} />
        <circle cx={150} cy={195} r={14} fill="#ff8a8a" opacity={0.45} />
        <circle cx={270} cy={195} r={14} fill="#ff8a8a" opacity={0.45} />
        <ellipse cx={210} cy={208} rx={22} ry={mouth / 2} fill="#7a1f1f" />
      </svg>
    </div>
  );
};
