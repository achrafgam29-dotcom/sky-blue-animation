import {Composition} from "remotion";
import {SkyBlue} from "./SkyBlue";
import {FPS, TOTAL} from "./timeline";

export const RemotionRoot = () => (
  <Composition id="SkyBlue" component={SkyBlue} durationInFrames={TOTAL} fps={FPS} width={1080} height={1920} />
);
