import timing from "./timing.json";
import script from "./script.json";

type TS = {frames: number; words?: {text: string; startMs: number; endMs: number}[]};
const ts = timing.scenes as TS[];

export const FPS = timing.fps;
export const LEAD = timing.lead; // silence before narration starts in each scene
export const TAIL = 12; // breathing room after narration
export const OVERLAP = 10; // cross-fade length between scenes
export const HAS_AUDIO = timing.hasAudio;

export const scenes = script.scenes.map((s, i) => ({...s, ...(ts[i] ?? {frames: 150})}));
export const starts = scenes.map((_, i) => scenes.slice(0, i).reduce((a, s) => a + s.frames, 0));
export const TOTAL = scenes.reduce((a, s) => a + s.frames, 0);

export const talkingAt = (frame: number) =>
  scenes.some((s, i) => frame >= starts[i] + LEAD && frame < starts[i] + s.frames - TAIL);
