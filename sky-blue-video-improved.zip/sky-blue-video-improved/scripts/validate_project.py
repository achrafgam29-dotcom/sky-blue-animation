import json
from pathlib import Path
root = Path(__file__).resolve().parent.parent
pkg = json.loads((root / 'package.json').read_text())
script = json.loads((root / 'src/script.json').read_text())
timing = json.loads((root / 'src/timing.json').read_text())
assert pkg['scripts']['render']
assert len(script['scenes']) == len(timing['scenes']), 'Scene count mismatch'
assert all(s.get('id') and s.get('text') for s in script['scenes'])
assert all(t.get('frames', 0) > 0 for t in timing['scenes'])
print(f"OK: {len(script['scenes'])} scenes, {sum(t['frames'] for t in timing['scenes'])} frames")
