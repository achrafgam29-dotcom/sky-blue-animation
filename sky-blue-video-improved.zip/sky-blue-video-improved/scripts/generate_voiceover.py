"""Generate Arabic narration per scene + word timings, then write src/timing.json.
Usage: python scripts/generate_voiceover.py [voice]   (default ar-SA-HamedNeural; try ar-EG-SalmaNeural)
Needs: pip install edge-tts, and ffprobe (ffmpeg) on PATH. Requires internet.
"""
import asyncio, json, math, pathlib, subprocess, sys
import edge_tts

ROOT = pathlib.Path(__file__).resolve().parent.parent
VOICE = sys.argv[1] if len(sys.argv) > 1 else "ar-SA-HamedNeural"
FPS, LEAD, TAIL = 30, 8, 12  # keep in sync with src/timeline.ts

async def synth(text, out):
    words = []
    with open(out, "wb") as fh:
        async for ch in edge_tts.Communicate(text, VOICE, boundary="WordBoundary").stream():
            if ch["type"] == "audio":
                fh.write(ch["data"])
            elif ch["type"] == "WordBoundary":
                words.append({"text": ch["text"], "startMs": ch["offset"] / 10000,
                              "endMs": (ch["offset"] + ch["duration"]) / 10000})
    return words

def duration(p):
    return float(subprocess.check_output(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(p)]))

async def main():
    script = json.load(open(ROOT / "src/script.json", encoding="utf-8"))
    (ROOT / "public/audio").mkdir(parents=True, exist_ok=True)
    scenes = []
    for s in script["scenes"]:
        out = ROOT / f"public/audio/{s['id']}.mp3"
        words = await synth(s["text"], out)
        d = duration(out)
        scenes.append({"frames": math.ceil(d * FPS) + LEAD + TAIL, "words": words})
        print(f"{s['id']}: {d:.2f}s, {len(words)} word marks")
    json.dump({"fps": FPS, "lead": LEAD, "hasAudio": True, "scenes": scenes},
              open(ROOT / "src/timing.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)

asyncio.run(main())
