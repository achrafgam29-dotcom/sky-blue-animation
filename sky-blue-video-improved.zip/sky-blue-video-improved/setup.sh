#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
echo "Installing Node dependencies..."
npm install
mkdir -p out public/audio
printf '\nInstallation complete.\n'
printf 'Preview: npm run studio\nRender MP4: npm run render\n'
